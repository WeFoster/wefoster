<div class="site-description-wrap <?php do_action('class_container');?>">
    <div class="site-description">


      <?php do_action('inside_site_description'); ?>
      
      <?php echo get_bloginfo('name'); ?>

      <span><?php echo get_bloginfo('description'); ?></span>

    </div>
</div>
