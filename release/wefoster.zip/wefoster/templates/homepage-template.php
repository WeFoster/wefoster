<?php
/*
Template Name: Homepage Template
*/
?>

 <?php
//To avoid duplicate code we are loading the same template as regular pages. The left sidebar is all done through CSS.
 get_template_part('page');
?>
