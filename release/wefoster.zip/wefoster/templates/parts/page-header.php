<div class="page-header <?php do_action('page_header_class'); ?>">
  <?php do_action('open_page_header'); ?>
  <h1>
    <?php echo wff_title(); ?><?php edit_post_link(__('<i class="fa fa-pencil edit-link"></i>')); ?>
  </h1>
    <?php do_action('close_page_header'); ?>
</div>
