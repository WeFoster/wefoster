<?php
////////////////
// Layout Default
///////////////

//define('WEFOSTER_LAYOUT_PRESET', 'full');
//define('WEFOSTER_HEADER', 'boxed');
//define('WEFOSTER_HEADER_STYLE', 'navbar-inverse');
//define('WEFOSTER_LAYOUT_PRESET ==_CLASS', 'container');
//define('WEFOSTER_MAIN_CLASS', 'col-sm-6');
//define('WEFOSTER_SIDEBAR_CLASS', 'col-sm-6');
//define('WEFOSTER_SIDEBAR_POSITION', 'wefoster-sidebar-left');

////////////////
// Default Logos
///////////////
?>
